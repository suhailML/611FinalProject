/*
File: main.java
Developer: Tristan Marchand, Evan Bosia
Email: tmarch@bu.edu
Last Edited: Wednesday, December 16, 2020

Description: Entry point to the program ~ run this file to start.
*/

public class main {

    public static void main(String[] args) {
        Program.run();
    }

}
