/*
Entry point to the program ~ run this file to start.
 */
public class main {

    public static void main(String[] args) {
        Program.run();
    }

}
